import prisma from "./database";

(async () => {
  const students = null; // TODO: Faça a implementação aqui
  console.log(students);
})